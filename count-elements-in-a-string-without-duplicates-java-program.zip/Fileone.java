import java.util.*;
public class Fileone{
    public static void main(String[] args) {
        Scanner ps = new Scanner(System.in);
        String sl = ps.next()+" ";
        int count = 0,check = 0;
        while(sl.charAt(count)!=' '){
            count++;
        }
        for(int i = 0;i<count;i++){
            int count2 = 0;
            for (int j = i; j < count; j++) {
                if (sl.charAt(i) == sl.charAt(j)) {
                    count2++;
                }
            }
            if (count2 == 1) {
                check++;
            }
        }
        System.out.println(check);
    }
}